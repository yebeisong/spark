import subprocess

# Blender应用程序的完整路径
exe_path = r"F:\Program Files\blender-4.2.0-alpha+main.05c1abe59c95-windows.amd64-release\blender.exe"

# 直接启动Blender
subprocess.Popen([exe_path])
